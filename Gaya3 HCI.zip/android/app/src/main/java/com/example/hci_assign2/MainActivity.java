package com.example.hci_assign2;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
